package edu.mum.main;


import java.util.Date;

import edu.mum.dao.impl.UserDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.mum.domain.User;
import edu.mum.service.UserService;

public class Main {


  public static void main(String[] args) {

      ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("context/applicationContext.xml");

      UserService userService=context.getBean(UserService.class);
     User user = new User();
     user.setAdmin(true);
     user.setEmail("medore@gmail.com");
     user.setFirstName("Rodrigue");
      user.setLastLogin(new Date());
     user.setLastName("medor");
     user.setRating(10);
     user.setVersion(34);
      userService.save(user);


      User user1 = new User();
      user1.setAdmin(false);
      user1.setEmail("medor@gmail.com");
      user1.setFirstName("Rodrigue");
      user1.setLastLogin(new Date());
      user1.setLastName("medor");
      user1.setRating(5);
      user1.setVersion(25);
      userService.save(user1);


      System.out.println("*********User***************");

      User iu = userService.findByEmail("medor@gmail.com");

      System.out.println("User Name  :"+ iu.getFirstName() +"  "+ iu.getLastName());

      // merge identity
      user.setEmail("jeanpierre@gmail.com");
      User us = userService.update(iu);

      user1.setEmail("saravalentin@gmail.com");
      User u = userService.update(user);

        userService.refresh(iu);

        userService.flush();

  }  
  
 }